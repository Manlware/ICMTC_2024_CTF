#!/bin/bash

openssl rsautl -decrypt -inkey id_rsa.pem -in /tmp/shell.sh | bash
